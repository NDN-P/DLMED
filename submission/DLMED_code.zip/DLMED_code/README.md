# DLMED — Brain Tumor Segmentation + Tumor-Type Classification (Multi-task Learning)

โค้ดของโปรเจกต์ พร้อมคำอธิบายวิธีใช้งาน แหล่งข้อมูล และการตั้งค่าที่จำเป็น

- ลิงก์โค้ด (GitHub): <https://github.com/NDN-P/DLMED>
- ผลการทดลองและรูปประกอบ: <https://github.com/NDN-P/DLMED/blob/main/results/RESULTS.md>

โมเดลเดียวที่ใช้ encoder ร่วมกัน เรียนรู้ 2 งานพร้อมกันจากภาพ MRI สมอง (T1-weighted contrast-enhanced) 1 ภาพ

1. **Segmentation** — หาบริเวณเนื้องอก (ผลลัพธ์เป็น mask, วัดด้วย Dice / IoU)
2. **Classification** — จำแนกชนิดเนื้องอก: meningioma / glioma / pituitary (วัดด้วย Precision / Recall / Macro-F1 และ Confusion Matrix)

## ไฟล์ในชุดนี้

โครงสร้างตามสไลด์บทที่ 10 และ Colab ของวิชา: `Net.py` + `TrainingCNN.py` → `model.pt` → `TestingCNN.py`

```
DLMED_code/
├── README.md                 ไฟล์นี้
├── training/                 การฝึกสอนโมเดล
│   ├── Net.py                โครงสร้างโมเดล (ResNet-34 encoder + U-Net decoder + classification head)
│   ├── TrainingCNN.py        โค้ดฝึกสอน
│   ├── Training.ipynb        โค้ดเดียวกันในรูปแบบ Colab
│   ├── prepare_data.py       แปลงไฟล์ .mat เป็น PNG
│   ├── splits.csv            การแบ่ง train / val / test ตามผู้ป่วย (2,194 / 434 / 436 ภาพ)
│   ├── requirements.txt
│   └── README.md             รายละเอียดเพิ่มเติม (ภาษาอังกฤษ)
└── inference/                การทดสอบโมเดล
    ├── Net.py
    ├── TestingCNN.py         โค้ดทดสอบ (ภาพเดียว และทั้งชุดทดสอบ)
    ├── inference.ipynb       โค้ดเดียวกันในรูปแบบ Colab
    ├── requirements.txt
    └── README.md             รายละเอียดเพิ่มเติม (ภาษาอังกฤษ)
```

ไฟล์น้ำหนักโมเดล (49 MB) ไม่ได้รวมอยู่ใน zip เพราะมีขนาดใหญ่ `TestingCNN.py` จะดาวน์โหลดจาก GitHub ให้อัตโนมัติในการรันครั้งแรก
หรือดาวน์โหลดเองได้ที่ <https://github.com/NDN-P/DLMED/raw/main/weights/C_mtl_equal_seed0.pt> แล้ววางเป็น `inference/model.pt`

## แหล่งข้อมูล

**Figshare Brain Tumor Dataset** (Jun Cheng) — ภาพ MRI 3,064 ภาพ จากผู้ป่วย 233 ราย เป็นไฟล์ `.mat` ที่มี `image`, `tumorMask`,
`label` (1 = meningioma, 2 = glioma, 3 = pituitary) และ `PID` (รหัสผู้ป่วย)

- ดาวน์โหลด: <https://figshare.com/articles/dataset/brain_tumor_dataset/1512427> (zip 4 ไฟล์)
- อ้างอิง: Cheng J. et al., "Enhanced Performance of Brain Tumor Classification via Tumor Region Augmentation and Partition",
  PLoS ONE 10(10), 2015. <https://doi.org/10.1371/journal.pone.0140381>
- แบ่งข้อมูล **ตามผู้ป่วย** (ไม่ให้ภาพของผู้ป่วยคนเดียวกันอยู่ข้ามชุด) ตามไฟล์ `training/splits.csv`

แตกไฟล์ `.mat` ทั้งหมดไว้ที่ `training/data/raw/`

## วิธีใช้งาน

ใช้ Python 3 (ทดสอบกับ Python 3.14) แนะนำให้ใช้ GPU สำหรับการฝึกสอน

### 1. ทดสอบโมเดล (inference)

```bash
cd inference
pip install -r requirements.txt
python TestingCNN.py path/to/image
```

- `path/to/image` เป็นไฟล์ `.mat` จากชุดข้อมูล หรือภาพ MRI `.png` / `.jpg`
- ผลลัพธ์: ชนิดเนื้องอกพร้อมความน่าจะเป็นของแต่ละคลาส และไฟล์ `<ชื่อภาพ>_pred.png` (สีแดง = บริเวณเนื้องอกที่โมเดลทำนาย,
  เส้นสีเขียว = เฉลย เฉพาะกรณีไฟล์ `.mat`)
- ถ้ามีชุดข้อมูลที่ `training/data/processed` โปรแกรมจะทดสอบทั้งชุด test (436 ภาพ) บันทึก `out.csv`
  และแสดง Precision / Recall / F1 / Confusion Matrix / Dice / IoU
- บน Colab: เปิด `inference.ipynb` แล้วรันทุกเซลล์ (ดาวน์โหลดน้ำหนักและให้อัปโหลดภาพเอง)

### 2. ฝึกสอนโมเดล (training)

```bash
cd training
pip install -r requirements.txt
python prepare_data.py --raw_dir data/raw --out_dir data/processed
python TrainingCNN.py
```

- ผลลัพธ์: `model.pt` (epoch ที่ดีที่สุดบนชุด validation), `history.csv`, `training_curves.png`, `sample_batch.png`
- นำ `model.pt` ไปวางใน `inference/` เพื่อทดสอบโมเดลที่ฝึกเอง
- บน Colab: เปิด `Training.ipynb` เลือก Runtime → GPU และวาง `processed.zip` (โฟลเดอร์ `data/processed` ที่ zip แล้ว) ไว้ใน Google Drive
  ตามโฟลเดอร์ที่ระบุในเซลล์ "Google Colab only"

## การตั้งค่าที่จำเป็น

ไลบรารี (อยู่ใน `requirements.txt`): torch ≥ 2.3, torchvision ≥ 0.18, numpy, pandas, pillow, scikit-learn, matplotlib, h5py

ค่าที่ใช้ฝึกสอน กำหนดไว้ตอนต้นของ `training/TrainingCNN.py` (ค่าเริ่มต้นคือโมเดลหลักของโปรเจกต์ การทดลอง C)

| การตั้งค่า | ค่า |
|---|---|
| ขนาดภาพ / batch size | 256 × 256 / 16 |
| Optimizer | AdamW, learning rate 3e-4 (เลือกจาก validation: 1e-4 / 3e-4 / 1e-3), weight decay 1e-4 |
| Scheduler / จำนวน epoch | cosine / 30 |
| Loss ของ segmentation | Binary Cross Entropy + Dice |
| Loss ของ classification | Cross Entropy |
| Loss รวม | `w_seg * L_seg + w_cls * L_cls` |
| Augmentation (เฉพาะ train) | horizontal flip, affine (หมุน ±15°, เลื่อน ±5 %, ย่อขยาย ±10 %), brightness / contrast |
| Normalization | ภาพระดับสีเทา, mean 0.449, std 0.226 |
| การเลือก epoch ที่ดีที่สุด | (Macro-F1 + Dice) / 2 บนชุด validation |

การทดลอง 4 แบบใช้โค้ดเดียวกัน เปลี่ยนเฉพาะน้ำหนักของ loss

| รหัส | การตั้งค่า | ความหมาย |
|---|---|---|
| A | `w_seg, w_cls = 0.0, 1.0` | classification อย่างเดียว |
| B | `w_seg, w_cls = 1.0, 0.0` | segmentation อย่างเดียว |
| C | `w_seg, w_cls = 1.0, 1.0` | multi-task น้ำหนักเท่ากัน (โมเดลหลัก) |
| D | `weighting = 'uncertainty'` | multi-task เรียนรู้น้ำหนักเอง (Kendall et al., 2018) |

การตั้งค่าของ inference อยู่ตอนต้นของ `inference/TestingCNN.py`: `model_path` (ไฟล์น้ำหนัก), `img_path` (ภาพที่ทดสอบ),
`image_size` (256 ต้องตรงกับตอนฝึกสอน)
